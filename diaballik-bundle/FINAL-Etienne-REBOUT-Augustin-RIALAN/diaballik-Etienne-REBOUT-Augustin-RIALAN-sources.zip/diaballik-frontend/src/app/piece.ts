export class Piece {

    constructor(public player : string, public color : string, public hasball : string) {
    }
  
  }